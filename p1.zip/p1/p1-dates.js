/*
    CIT 281 Project 1
    Name: Adaline Witz
*/

function currentday() 
{
    const days = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    console.log(days[new Date().getDay()]);
}

currentday();